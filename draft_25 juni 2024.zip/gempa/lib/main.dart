import 'package:flutter/material.dart';
import 'package:gempa/helpers/userhelper.dart';
import 'package:gempa/model/user.dart';
import 'package:gempa/pages/loginpage.dart';
import 'package:page_transition/page_transition.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Create a default admin account
  UserHelper userHelper = UserHelper();
  User admin = User(
    id: 1,
    username: 'admin',
    password: 'admin123', // Remember to hash the password in a real application
    role: 'admin',
  );
  List<User> users = await userHelper.getUsers();
  if (!users.any((user) => user.username == 'admin')) {
    await userHelper.registerUser(admin);
  }

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: SplashScreen(),
    );
  }
}
class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(Duration(seconds: 3), () {
      Navigator.pushReplacement(
        context,
        PageTransition(
          type: PageTransitionType.fade,
          child: LoginPage(),
          duration: Duration(seconds: 1),
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: DecoratedBox(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.red.shade900, Colors.black],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Center(
          child: Image.asset('assets/image.png', height: 200),
        ),
      ),
    );
  }
}