import 'dart:convert';
import 'package:gempa/model/user.dart';
import 'package:shared_preferences/shared_preferences.dart';

class UserHelper {
  static const String _keyUsers = 'users';

  Future<void> registerUser(User user) async {
    final prefs = await SharedPreferences.getInstance();
    final String? usersString = prefs.getString(_keyUsers);
    List<User> users = usersString != null
        ? List<User>.from(
            json.decode(usersString).map((e) => User.fromMap(e)))
        : [];
    users.add(user);
    prefs.setString(
        _keyUsers, json.encode(users.map((e) => e.toMap()).toList()));
  }

  Future<User?> loginUser(String username, String password) async {
    final prefs = await SharedPreferences.getInstance();
    final String? usersString = prefs.getString(_keyUsers);
    if (usersString != null) {
      List<dynamic> list = json.decode(usersString);
      List<User> users = list.map((e) => User.fromMap(e)).toList();

      for (User user in users) {
        if (user.username == username && user.password == password) {
          return user;
        }
      }
    }
    return null;
  }

  Future<List<User>> getUsers() async {
    final prefs = await SharedPreferences.getInstance();
    final String? usersString = prefs.getString(_keyUsers);
    if (usersString != null) {
      List<dynamic> list = json.decode(usersString);
      return list.map((e) => User.fromMap(e)).toList();
    }
    return [];
  }
}
