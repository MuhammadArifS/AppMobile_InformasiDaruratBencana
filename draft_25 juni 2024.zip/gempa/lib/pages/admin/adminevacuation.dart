import 'package:flutter/material.dart';
import 'package:gempa/helpers/evacuation_helper.dart';
import 'package:gempa/model/evacuation.dart';
import 'package:gempa/pages/admin/addevacuationpage.dart';

class AdminEvacuation extends StatefulWidget {
  @override
  _AdminEvacuationState createState() => _AdminEvacuationState();
}

class _AdminEvacuationState extends State<AdminEvacuation> {
  late Future<List<Evacuation>> futureEvacuations;

  @override
  void initState() {
    super.initState();
    futureEvacuations = EvacuationHelper().getEvacuations();
  }

  Future<void> _reloadEvacuations() async {
    setState(() {
      futureEvacuations = EvacuationHelper().getEvacuations();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Evacuation'),
        backgroundColor: Colors.red,
      ),
      body: FutureBuilder<List<Evacuation>>(
        future: futureEvacuations,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(child: Text('No evacuations added.'));
          } else {
            return RefreshIndicator(
              onRefresh: _reloadEvacuations,
              child: ListView.builder(
                itemCount: snapshot.data!.length,
                itemBuilder: (context, index) {
                  final evacuation = snapshot.data![index];
                  return Card(
                    child: ListTile(
                      title: Text('Tanggal: ${evacuation.date}'),
                      subtitle: Text(evacuation.location), 
                    ),
                  );
                },
              ),
            );
          }
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          await Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => AddEvacuationPage()),
          );
          _reloadEvacuations();
        },
        child: Icon(Icons.add),
        backgroundColor: Colors.red,
      ),
    );
  }
}
