import 'package:flutter/material.dart';
import 'package:gempa/helpers/evacuation_helper.dart';
import 'package:gempa/model/evacuation.dart';

class AddEvacuationPage extends StatefulWidget {
  @override
  _AddEvacuationPageState createState() => _AddEvacuationPageState();
}

class _AddEvacuationPageState extends State<AddEvacuationPage> {
  final _formKey = GlobalKey<FormState>();
  final _descriptionController = TextEditingController();
  final _locationController = TextEditingController();
  DateTime _selectedDate = DateTime.now(); // Tambahkan variabel untuk tanggal

  @override
  void dispose() {
    _descriptionController.dispose();
    _locationController.dispose();
    super.dispose();
  }

  void _saveEvacuation() async {
    if (_formKey.currentState!.validate()) {
      // Generate unique id based on current timestamp
      int id = DateTime.now().millisecondsSinceEpoch;

      final evacuation = Evacuation(
        id: id,
        description: _descriptionController.text,
        location: _locationController.text,
        date: _selectedDate, // Assign selected date to evacuation object
      );
      await EvacuationHelper().insertEvacuation(evacuation);
      Navigator.pop(context, true); // Return true when an evacuation is added
    }
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime(2020),
      lastDate: DateTime(2030),
    );
    if (picked != null && picked != _selectedDate) {
      setState(() {
        _selectedDate = picked;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Add Evacuation'),
        backgroundColor: Colors.red,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                controller: _descriptionController,
                decoration: InputDecoration(labelText: 'Description'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter a description';
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: _locationController,
                decoration: InputDecoration(labelText: 'Location'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter a location';
                  }
                  return null;
                },
              ),
              SizedBox(height: 20),
              TextButton(
                onPressed: () => _selectDate(context), // Panggil fungsi untuk memilih tanggal
                child: Text(
                  'Select Date: ${_selectedDate.day}/${_selectedDate.month}/${_selectedDate.year}',
                ),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: _saveEvacuation,
                child: Text('Save'),
                style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

