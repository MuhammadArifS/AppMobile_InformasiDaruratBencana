import 'package:flutter/material.dart';
import 'package:gempa/helpers/evacuation_helper.dart';
import 'package:gempa/model/evacuation.dart';

class EditEvacuationPage extends StatefulWidget {
  final Evacuation evacuation;

  EditEvacuationPage(this.evacuation);

  @override
  _EditEvacuationPageState createState() => _EditEvacuationPageState();
}

class _EditEvacuationPageState extends State<EditEvacuationPage> {
  final _formKey = GlobalKey<FormState>();
  final _descriptionController = TextEditingController();
  final _locationController = TextEditingController();
  DateTime _selectedDate = DateTime.now();

  @override
  void initState() {
    super.initState();
    _descriptionController.text = widget.evacuation.description;
    _locationController.text = widget.evacuation.location;
    _selectedDate = widget.evacuation.date;
  }

  @override
  void dispose() {
    _descriptionController.dispose();
    _locationController.dispose();
    super.dispose();
  }

  void _saveChanges() async {
    if (_formKey.currentState!.validate()) {
      final updatedEvacuation = Evacuation(
        id: widget.evacuation.id,
        description: _descriptionController.text,
        location: _locationController.text,
        date: _selectedDate,
      );
      await EvacuationHelper().updateEvacuation(updatedEvacuation);
      Navigator.pop(context, true); // Return true when evacuation is updated
    }
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime(2020),
      lastDate: DateTime(2030),
    );
    if (picked != null && picked != _selectedDate) {
      setState(() {
        _selectedDate = picked;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Edit Evacuation'),
        backgroundColor: Colors.red,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                controller: _descriptionController,
                decoration: InputDecoration(labelText: 'Description'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter a description';
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: _locationController,
                decoration: InputDecoration(labelText: 'Location'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter a location';
                  }
                  return null;
                },
              ),
              SizedBox(height: 20),
              TextButton(
                onPressed: () => _selectDate(context),
                child: Text(
                  'Select Date: ${_selectedDate.day}/${_selectedDate.month}/${_selectedDate.year}',
                ),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: _saveChanges,
                child: Text('Save'),
                style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
