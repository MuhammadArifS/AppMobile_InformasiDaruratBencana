import 'package:flutter/material.dart';
import 'package:gempa/model/gempabumi.dart';
import 'package:gempa/pages/user/evacuationpage.dart';
import 'package:gempa/pages/user/homepage.dart';
import 'package:url_launcher/url_launcher.dart'; // Import the url_launcher package

class EmergencyCallPage extends StatefulWidget {
  @override
  _EmergencyCallPageState createState() => _EmergencyCallPageState();
}

class _EmergencyCallPageState extends State<EmergencyCallPage> {
  late Future<List<Earthquake>> futureEarthquakes;

  int _selectedIndex = 2;

  void _onItemTapped(int index) {
    if (index != _selectedIndex) {
      setState(() {
        _selectedIndex = index;
      });

      switch (index) {
        case 0:
          print('Navigating to Homepage');
          Navigator.of(context).pushAndRemoveUntil(
            MaterialPageRoute(builder: (context) => UserHomePage()),
            (Route<dynamic> route) => false,
          );
          break;
        case 1:
          print('Navigating to EvacuationPage');
          Navigator.of(context).pushAndRemoveUntil(
            MaterialPageRoute(builder: (context) => EvacuationPage()),
            (Route<dynamic> route) => false,
          );
          break;
        case 2:
          print('Already on EmergencyCallPage');
          Navigator.of(context).pushAndRemoveUntil(
            MaterialPageRoute(builder: (context) => EmergencyCallPage()),
            (Route<dynamic> route) => false,
          );
          break;
      }
    }
  }

  void _makePhoneCall(String phoneNumber) async {
    final Uri launchUri = Uri(
      scheme: 'tel',
      path: phoneNumber,
    );
    if (await canLaunch(launchUri.toString())) {
      await launch(launchUri.toString());
    } else {
      throw 'Could not launch $phoneNumber';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Siaga'),
        backgroundColor: Colors.red,
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Image.network('assets/image.png'),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Expanded(
              child: ElevatedButton.icon(
                icon: Icon(Icons.local_police, size: 50),
                label: Text('Hubungi Polisi', style: TextStyle(fontSize: 24)),
                onPressed: () {
                  _makePhoneCall('110'); // Nomor darurat Polisi
                },
                style: ElevatedButton.styleFrom(
                  foregroundColor: Colors.white, backgroundColor: Colors.red, // Text color
                  padding: EdgeInsets.symmetric(vertical: 20),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                ),
              ),
            ),
            SizedBox(height: 10),
            Expanded(
              child: ElevatedButton.icon(
                icon: Icon(Icons.local_hospital, size: 50),
                label: Text('Hubungi Ambulans', style: TextStyle(fontSize: 24)),
                onPressed: () {
                  _makePhoneCall('118'); // Nomor darurat Ambulans
                },
                style: ElevatedButton.styleFrom(
                  foregroundColor: Colors.white, backgroundColor: Colors.red, // Text color
                  padding: EdgeInsets.symmetric(vertical: 20),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                ),
              ),
            ),
            SizedBox(height: 10),
            Expanded(
              child: ElevatedButton.icon(
                icon: Icon(Icons.local_fire_department, size: 50),
                label: Text('Hubungi Pemadam Kebakaran', style: TextStyle(fontSize: 24)),
                onPressed: () {
                  _makePhoneCall('113'); // Nomor darurat Pemadam Kebakaran
                },
                style: ElevatedButton.styleFrom(
                  foregroundColor: Colors.white, backgroundColor: Colors.red, // Text color
                  padding: EdgeInsets.symmetric(vertical: 20),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                ),
              ),
            ),
            SizedBox(height: 10),
            Expanded(
              child: ElevatedButton.icon(
                icon: Icon(Icons.warning, size: 50),
                label: Text('Hubungi BNPB', style: TextStyle(fontSize: 24)),
                onPressed: () {
                  _makePhoneCall('117'); // Nomor darurat BNPB
                },
                style: ElevatedButton.styleFrom(
                  foregroundColor: Colors.white, backgroundColor: Colors.red, // Text color
                  padding: EdgeInsets.symmetric(vertical: 20),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        backgroundColor: Colors.red,
        selectedItemColor: Colors.white,
        unselectedItemColor: Colors.white70,
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.place),
            label: 'Evacuation',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.phone),
            label: 'Emergency Call',
          ),
        ],
      ),
    );
  }
}
