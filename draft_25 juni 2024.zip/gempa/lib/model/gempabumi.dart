class Earthquake {
  final String date;
  final String time;
  final double magnitude;
  final double latitude;
  final double longitude;
  final String region;

  Earthquake({
    required this.date,
    required this.time,
    required this.magnitude,
    required this.latitude,
    required this.longitude,
    required this.region,
  });

  factory Earthquake.fromJson(Map<String, dynamic> json) {
    return Earthquake(
      date: json['Tanggal'] ?? 'N/A',
      time: json['Jam'] ?? 'N/A',
      magnitude: _parseDouble(json['Magnitude']),
      latitude: _parseCoordinate(json['Lintang']),
      longitude: _parseCoordinate(json['Bujur']),
      region: json['Wilayah'] ?? 'N/A',
    );
  }

  static double _parseDouble(String? value) {
    if (value == null || value.isEmpty) {
      return 0.0;
    }
    try {
      return double.parse(value);
    } catch (e) {
      return 0.0; // Atau nilai default yang sesuai
    }
  }

  static double _parseCoordinate(String? value) {
    if (value == null || value.isEmpty) {
      return 0.0;
    }
    try {
      // Hapus karakter non-angka dan koma, lalu konversi ke double
      return double.parse(value.replaceAll(RegExp(r'[^\d.-]'), ''));
    } catch (e) {
      return 0.0; // Atau nilai default yang sesuai
    }
  }
}
