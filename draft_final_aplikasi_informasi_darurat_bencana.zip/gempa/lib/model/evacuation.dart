class Evacuation {
  final int id; // Properti id
  final String description;
  final String location;
  final DateTime date; // Properti tanggal

  Evacuation({
    required this.id,
    required this.description,
    required this.location,
    required this.date,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'description': description,
      'location': location,
      'date': date.millisecondsSinceEpoch, // Ubah tanggal menjadi milisekon sejak epoch
    };
  }

  factory Evacuation.fromMap(Map<String, dynamic> map) {
    return Evacuation(
      id: map['id'],
      description: map['description'],
      location: map['location'],
      date: DateTime.fromMillisecondsSinceEpoch(map['date']),
    );
  }
}
