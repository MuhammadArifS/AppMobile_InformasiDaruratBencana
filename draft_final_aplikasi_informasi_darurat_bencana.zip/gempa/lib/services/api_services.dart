import 'dart:convert';
import 'package:gempa/model/gempabumi.dart';
import 'package:http/http.dart' as http;


class ApiService {
  static const String _baseUrl = 'https://data.bmkg.go.id/DataMKG/TEWS/gempadirasakan.json';

  Future<List<Earthquake>> fetchEarthquakes() async {
    final response = await http.get(Uri.parse(_baseUrl));

    if (response.statusCode == 200) {
      print(response.body); // Debug log untuk memastikan data diterima
      List<dynamic> body = jsonDecode(response.body)['Infogempa']['gempa'] ?? [];
      List<Earthquake> earthquakes = body.map((dynamic item) => Earthquake.fromJson(item)).toList();
      return earthquakes;
    } else {
      throw Exception('Failed to load earthquakes');
    }
  }
}
