package com.example.gempa

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
