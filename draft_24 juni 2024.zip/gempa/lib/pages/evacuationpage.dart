// pages/evacuationpage.dart
import 'package:flutter/material.dart';
import 'package:gempa/helpers/evacuation_helper.dart';
import 'package:gempa/model/evacuation.dart';
import 'package:gempa/pages/emergencypage.dart';
import 'package:gempa/pages/homepage.dart';
import 'package:gempa/pages/addevacuationpage.dart';

class EvacuationPage extends StatefulWidget {
  @override
  _EvacuationPageState createState() => _EvacuationPageState();
}

class _EvacuationPageState extends State<EvacuationPage> {
  late Future<List<Evacuation>> futureEvacuations;
  int _selectedIndex = 1;

  @override
  void initState() {
    super.initState();
    futureEvacuations = EvacuationHelper().getEvacuations();
  }

  void _onItemTapped(int index) {
    if (index != _selectedIndex) {
      setState(() {
        _selectedIndex = index;
      });
      switch (index) {
        case 0:
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => Homepage()),
          );
          break;
        case 1:
          break;
        case 2:
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => EmergencyCallPage()),
          );
          break;
      }
    }
  }

  void _navigateToAddEvacuationPage() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => AddEvacuationPage()),
    );
    if (result == true) {
      setState(() {
        futureEvacuations = EvacuationHelper().getEvacuations();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Evacuation'),
        backgroundColor: Colors.red,
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Image.network('assets/image.png'),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _navigateToAddEvacuationPage,
        child: Icon(Icons.add),
        backgroundColor: Colors.red,
      ),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        backgroundColor: Colors.red,
        selectedItemColor: Colors.white,
        unselectedItemColor: Colors.white70,
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.place),
            label: 'Evacuation',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.phone),
            label: 'Emergency Call',
          ),
        ],
      ),
      body: FutureBuilder<List<Evacuation>>(
        future: futureEvacuations,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(child: Text('No evacuations added.'));
          } else {
            return ListView.builder(
              itemCount: snapshot.data!.length,
              itemBuilder: (context, index) {
                final evacuation = snapshot.data![index];
                return Card(
                  child: ListTile(
                    title: Text(evacuation.description),
                    subtitle: Text(evacuation.location),
                  ),
                );
              },
            );
          }
        },
      ),
    );
  }
}
