import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:gempa/model/evacuation.dart';

class EvacuationHelper {
  static const String _keyEvacuations = 'evacuations';

  Future<void> insertEvacuation(Evacuation evacuation) async {
    final prefs = await SharedPreferences.getInstance();
    final String? evacuationsString = prefs.getString(_keyEvacuations);
    List<Evacuation> evacuations = evacuationsString != null
        ? List<Evacuation>.from(
            json.decode(evacuationsString).map((e) => Evacuation.fromMap(e)))
        : [];
    evacuations.add(evacuation);
    prefs.setString(
        _keyEvacuations, json.encode(evacuations.map((e) => e.toMap()).toList()));
  }

  Future<List<Evacuation>> getEvacuations() async {
    final prefs = await SharedPreferences.getInstance();
    final String? evacuationsString = prefs.getString(_keyEvacuations);
    if (evacuationsString != null) {
      List<dynamic> list = json.decode(evacuationsString);
      return list.map((e) => Evacuation.fromMap(e)).toList();
    }
    return [];
  }

  Future<void> updateEvacuation(Evacuation updatedEvacuation) async {
    final prefs = await SharedPreferences.getInstance();
    final String? evacuationsString = prefs.getString(_keyEvacuations);
    if (evacuationsString != null) {
      List<dynamic> list = json.decode(evacuationsString);
      List<Evacuation> evacuations =
          list.map((e) => Evacuation.fromMap(e)).toList();

      // Find the index of the evacuation to update
      int index =
          evacuations.indexWhere((evacuation) => evacuation.id == updatedEvacuation.id);
      if (index != -1) {
        evacuations[index] = updatedEvacuation;
        prefs.setString(
            _keyEvacuations, json.encode(evacuations.map((e) => e.toMap()).toList()));
      }
    }
  }

  Future<void> deleteEvacuation(int id) async {
    final prefs = await SharedPreferences.getInstance();
    final String? evacuationsString = prefs.getString(_keyEvacuations);
    if (evacuationsString != null) {
      List<dynamic> list = json.decode(evacuationsString);
      List<Evacuation> evacuations =
          list.map((e) => Evacuation.fromMap(e)).toList();

      // Find the index of the evacuation to delete
      int index = evacuations.indexWhere((evacuation) => evacuation.id == id);
      if (index != -1) {
        evacuations.removeAt(index);
        prefs.setString(
            _keyEvacuations, json.encode(evacuations.map((e) => e.toMap()).toList()));
      }
    }
  }
}

